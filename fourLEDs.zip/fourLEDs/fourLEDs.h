
#include <Arduino.h>

class fourLEDs
{
  public:
    fourLEDs(int pins[4]);
    void begin();
    void upCount();
    void allOff();
  private:
    int _pins[4];
    
};
