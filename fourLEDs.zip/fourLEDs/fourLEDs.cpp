
#include <fourLeds.h>

fourLEDs::fourLEDs(int pins[4])
{
  for(int i=0;i<4;i++)
  {
    _pins[i] = pins[i];
  }
}

void fourLEDs::begin()
{
  for(int i=0;i<4;i++)
  {
    pinMode(_pins[i],OUTPUT);
  }
}

void fourLEDs::allOff()
{
  for (int i=0;i<4;i++)
  {
    digitalWrite(_pins[i],LOW);
    //delay(200);
  }
}

void fourLEDs::upCount()
{
  for (byte ctr = 0; ctr<16; ctr++)
  {
    for (int i = 0; i < 4; i++)
    {
      if(bitRead(ctr,i)==1)
      {
        digitalWrite(_pins[i],HIGH);
        //delay(100);
      }
      else
      {
        digitalWrite(_pins[i],LOW);
        //delay(100);
      }
      
    }
    delay(500);
  }
}


